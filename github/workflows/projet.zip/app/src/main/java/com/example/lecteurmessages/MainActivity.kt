package com.example.lecteurmessages

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        val titre = TextView(this).apply {
            text = "Lecteur de messages"
            textSize = 24f
            gravity = Gravity.CENTER
        }

        val explication = TextView(this).apply {
            text = "Autorise l'accès aux notifications. Ensuite, chaque message reçu sur WhatsApp, Messenger ou Telegram sera lu à voix haute."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 32)
        }

        val bouton = Button(this).apply {
            text = "Autoriser l'accès aux notifications"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        layout.addView(titre)
        layout.addView(explication)
        layout.addView(bouton)
        setContentView(layout)
    }
}
