package com.example.lecteurmessages

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class MessageListener : NotificationListenerService(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsPret = false

    // Apps surveillées : nom technique -> nom lu à voix haute
    private val appsSurveillees = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "com.facebook.orca" to "Messenger",
        "org.telegram.messenger" to "Telegram"
    )

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.FRENCH
            ttsPret = true
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val nomApp = appsSurveillees[sbn.packageName] ?: return
        val notif = sbn.notification

        // Ignore les notifications "résumé" (ex : "3 nouveaux messages")
        if (notif.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = notif.extras
        val expediteur = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val message = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        if (!ttsPret) return

        tts?.speak(
            "Message de $expediteur sur $nomApp : $message",
            TextToSpeech.QUEUE_ADD,
            null,
            sbn.key
        )
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
