package com.example.lecteurmessages

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private var tts: TextToSpeech? = null
    private var ttsPret = false
    private lateinit var statut: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale.FRENCH)
                ttsPret = true
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
            } else {
                Toast.makeText(this, "Synthèse vocale indisponible (erreur $status)", Toast.LENGTH_LONG).show()
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        val titre = TextView(this).apply {
            text = "Lecteur de messages"
            textSize = 24f
            gravity = Gravity.CENTER
        }

        statut = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 32)
        }

        val boutonAcces = Button(this).apply {
            text = "Autoriser l'accès aux notifications"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        val boutonTest = Button(this).apply {
            text = "Tester la voix"
            setOnClickListener {
                if (ttsPret) {
                    tts?.speak(
                        "Bonjour, ceci est un test. Message de Paul sur WhatsApp : salut, ça va ?",
                        TextToSpeech.QUEUE_FLUSH, null, "test"
                    )
                } else {
                    Toast.makeText(this@MainActivity, "La voix n'est pas encore prête", Toast.LENGTH_LONG).show()
                }
            }
        }

        layout.addView(titre)
        layout.addView(statut)
        layout.addView(boutonAcces)
        layout.addView(boutonTest)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        val actives = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val ok = actives.contains(packageName)
        statut.text = if (ok) "✅ Accès aux notifications : activé" else "❌ Accès aux notifications : désactivé"
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
